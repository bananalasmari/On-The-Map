//
//  AppDelegate.swift
//  MovieApp
//
//  Created by Banan Mohammed on 19/09/1440 AH.
//  Copyright © 1440 Banan Mohammed. All rights reserved.
//
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

}

