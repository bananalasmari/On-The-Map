//
//  AppDelegate.swift
//  MovieApp
//
//  Created by Banan Mohammed on 19/09/1440 AH.
//  Copyright © 1440 Banan Mohammed. All rights reserved.
//
import Foundation

struct Constants {
    static let ApplicationId = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
    static let APIKey = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
}
