//
//  AppDelegate.swift
//  MovieApp
//
//  Created by Banan Mohammed on 19/09/1440 AH.
//  Copyright © 1440 Banan Mohammed. All rights reserved.
//

import Foundation

struct UpdateLocationResponse: Codable {
    let updatedAt: String?
}
